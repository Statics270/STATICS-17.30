# AGS S17


# Features
- ingame
- mcp
- inventory
- abilities
- building
- editing
- lategame
- proper fixes
- aircraft jump
- gameplay fixes
- vehicles
- Teams
- Creative
- IA (soon)
